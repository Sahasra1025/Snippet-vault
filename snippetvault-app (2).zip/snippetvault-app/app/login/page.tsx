"use client";

import Link from "next/link";

export default function Login() {
  return (
    <div style={{ padding: "40px" }}>
      <h1>Login Page</h1>

      <input placeholder="Email" />
      <br /><br />

      <input type="password" placeholder="Password" />
      <br /><br />

      <button>Login</button>

      <br /><br />

      <p>
        Don't have an account? <Link href="/register">Register</Link>
      </p>
    </div>
  );
}