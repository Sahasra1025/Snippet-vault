"use client";

import Link from "next/link";

export default function Register() {
  return (
    <div style={{ padding: "40px" }}>
      <h1>Register Page</h1>

      <input placeholder="Email" />
      <br /><br />

      <input type="password" placeholder="Password" />
      <br /><br />

      <button>Register</button>

      <br /><br />

      <p>
        Already have an account? <Link href="/login">Login</Link>
      </p>
    </div>
  );
}